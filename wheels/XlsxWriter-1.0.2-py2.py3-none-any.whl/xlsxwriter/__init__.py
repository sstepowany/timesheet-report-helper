__version__ = '1.0.2'
__VERSION__ = __version__
from .workbook import Workbook
